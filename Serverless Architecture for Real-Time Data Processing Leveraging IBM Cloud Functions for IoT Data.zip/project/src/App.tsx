import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  Clock,
  Users,
  CheckCircle,
  AlertCircle,
  Activity,
  Cpu,
  Signal,
  Gauge,
  TrendingUp,
  RefreshCw
} from 'lucide-react';

// Mock real-time data that would come from IBM Cloud Functions
const mockIoTMetrics = {
  activeDevices: 128,
  dataProcessingRate: '2.4k/s',
  systemLatency: '45ms',
  cpuUtilization: 67,
  memoryUsage: 72,
  activeEmployees: 42,
  averageHours: 6.8,
  completedTasks: 156,
  pendingTasks: 23,
  systemHealth: {
    status: 'Healthy',
    uptime: '99.99%',
    lastIncident: '8d ago'
  },
  realtimeMetrics: [
    { timestamp: '08:00', value: 85 },
    { timestamp: '09:00', value: 87 },
    { timestamp: '10:00', value: 92 },
    { timestamp: '11:00', value: 89 },
    { timestamp: '12:00', value: 94 }
  ],
  topPerformers: [
    { name: 'Sarah Chen', score: 95, tasks: 34 },
    { name: 'Michael Park', score: 92, tasks: 28 },
    { name: 'Emma Rodriguez', score: 89, tasks: 31 }
  ]
};

function MetricCard({ icon: Icon, title, value, trend, status }: {
  icon: React.ElementType;
  title: string;
  value: string | number;
  trend?: string;
  status?: 'success' | 'warning' | 'error';
}) {
  const statusColors = {
    success: 'bg-green-50 text-green-600',
    warning: 'bg-yellow-50 text-yellow-600',
    error: 'bg-red-50 text-red-600'
  };

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className={`p-3 ${status ? statusColors[status] : 'bg-indigo-50'} rounded-lg`}>
            <Icon className={`w-6 h-6 ${status ? statusColors[status] : 'text-indigo-600'}`} />
          </div>
          <div>
            <p className="text-sm text-gray-500">{title}</p>
            <p className="text-2xl font-semibold text-gray-900">{value}</p>
          </div>
        </div>
        {trend && (
          <span className="text-sm text-green-600 bg-green-50 px-2.5 py-0.5 rounded-full">
            {trend}
          </span>
        )}
      </div>
    </div>
  );
}

function SystemHealthCard() {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-gray-900">System Health</h2>
        <div className="flex items-center space-x-2">
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-sm bg-green-50 text-green-600">
            <div className="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
            {mockIoTMetrics.systemHealth.status}
          </span>
        </div>
      </div>
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <span className="text-gray-600">Uptime</span>
          <span className="font-medium">{mockIoTMetrics.systemHealth.uptime}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-600">Last Incident</span>
          <span className="font-medium">{mockIoTMetrics.systemHealth.lastIncident}</span>
        </div>
        <div className="mt-4 pt-4 border-t">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-500">Last updated</span>
            <span className="text-gray-900">2 minutes ago</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function PerformanceChart() {
  const data = mockIoTMetrics.realtimeMetrics;
  const maxValue = Math.max(...data.map(d => d.value));
  const minValue = Math.min(...data.map(d => d.value));
  
  return (
    <div className="relative h-64">
      {/* Y-axis labels */}
      <div className="absolute left-0 top-0 bottom-0 w-12 flex flex-col justify-between text-xs text-gray-500">
        <span>{maxValue}</span>
        <span>{Math.round((maxValue + minValue) / 2)}</span>
        <span>{minValue}</span>
      </div>
      
      {/* Chart area */}
      <div className="absolute left-12 right-0 top-0 bottom-0">
        {/* Grid lines */}
        <div className="absolute inset-0 grid grid-cols-1 grid-rows-4 border-gray-200">
          <div className="border-b"></div>
          <div className="border-b"></div>
          <div className="border-b"></div>
          <div className="border-b"></div>
        </div>
        
        {/* Data points and lines */}
        <div className="absolute inset-0 flex items-end justify-between">
          {data.map((point, index) => {
            const height = ((point.value - minValue) / (maxValue - minValue)) * 100;
            return (
              <div key={index} className="flex flex-col items-center w-full">
                <div 
                  className="w-2 bg-indigo-500 rounded-t"
                  style={{ height: `${height}%` }}
                ></div>
                <span className="mt-2 text-xs text-gray-500">{point.timestamp}</span>
              </div>
            );
          })}
        </div>
        
        {/* Connecting line */}
        <svg className="absolute inset-0" style={{ height: '100%', width: '100%' }}>
          <polyline
            points={data.map((point, index) => {
              const x = (index / (data.length - 1)) * 100;
              const y = 100 - ((point.value - minValue) / (maxValue - minValue)) * 100;
              return `${x}% ${y}%`;
            }).join(' ')}
            fill="none"
            stroke="#6366F1"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
    </div>
  );
}

function App() {
  const [timeframe, setTimeframe] = useState('today');
  const [lastUpdate, setLastUpdate] = useState(new Date());

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdate(new Date());
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold text-gray-900">IoT Performance Dashboard</h1>
              <div className="flex items-center text-sm text-gray-500">
                <RefreshCw className="w-4 h-4 mr-1" />
                Last updated: {lastUpdate.toLocaleTimeString()}
              </div>
            </div>
            <select
              value={timeframe}
              onChange={(e) => setTimeframe(e.target.value)}
              className="bg-white border border-gray-300 rounded-md px-3 py-1.5 text-sm"
            >
              <option value="today">Today</option>
              <option value="week">This Week</option>
              <option value="month">This Month</option>
            </select>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* System Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            icon={Signal}
            title="Active IoT Devices"
            value={mockIoTMetrics.activeDevices}
            trend="+8%"
            status="success"
          />
          <MetricCard
            icon={Gauge}
            title="Processing Rate"
            value={mockIoTMetrics.dataProcessingRate}
            status="success"
          />
          <MetricCard
            icon={Clock}
            title="System Latency"
            value={mockIoTMetrics.systemLatency}
            status="success"
          />
          <MetricCard
            icon={Cpu}
            title="CPU Utilization"
            value={`${mockIoTMetrics.cpuUtilization}%`}
            status={mockIoTMetrics.cpuUtilization > 80 ? 'warning' : 'success'}
          />
        </div>

        {/* Three Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Real-time Performance */}
          <div className="lg:col-span-2 bg-white rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-gray-900">Real-time Performance</h2>
              <Activity className="w-5 h-5 text-gray-400" />
            </div>
            <PerformanceChart />
          </div>

          {/* System Health */}
          <div className="lg:col-span-1">
            <SystemHealthCard />
          </div>
        </div>

        {/* Employee Metrics */}
        <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Task Metrics */}
          <div className="bg-white rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-gray-900">Task Metrics</h2>
              <CheckCircle className="w-5 h-5 text-gray-400" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-500">Completed Tasks</p>
                <p className="text-2xl font-semibold text-gray-900">{mockIoTMetrics.completedTasks}</p>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-500">Pending Tasks</p>
                <p className="text-2xl font-semibold text-gray-900">{mockIoTMetrics.pendingTasks}</p>
              </div>
            </div>
          </div>

          {/* Top Performers */}
          <div className="bg-white rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-gray-900">Top Performers</h2>
              <TrendingUp className="w-5 h-5 text-gray-400" />
            </div>
            <div className="space-y-4">
              {mockIoTMetrics.topPerformers.map((performer, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900">{performer.name}</p>
                    <p className="text-sm text-gray-500">{performer.tasks} tasks completed</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-indigo-600">{performer.score}%</span>
                    <div className="w-2 h-2 rounded-full bg-green-500"></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;